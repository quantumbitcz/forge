from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_pagination_returns_size_items():
    r = client.get("/items?page=0&size=10")
    assert r.status_code == 200
    assert len(r.json()) == 10    # currently fails — returns 11
