package com.example

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import javax.annotation.PostConstruct

@SpringBootApplication
class App {
    @PostConstruct fun init() { println("booted") }
}

fun main(args: Array<String>) { runApplication<App>(*args) }
