import XCTest
@testable import Counter

final class CounterTests: XCTestCase {
    func testConcurrentIncrements() async {
        let c = Counter()
        await withTaskGroup(of: Void.self) { group in
            for _ in 0..<1000 { group.addTask { c.increment() } }
        }
        XCTAssertEqual(c.count, 1000)   // currently flaky due to race
    }
}
