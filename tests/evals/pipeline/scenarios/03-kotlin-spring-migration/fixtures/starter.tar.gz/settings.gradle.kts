rootProject.name = "spring-migration-fixture"
