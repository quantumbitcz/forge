<?php
namespace Example;

class UserRepository {
    public function __construct(private \PDO $pdo) {}

    // BUG: string-concatenated SQL — vulnerable to injection.
    public function findByEmail(string $email): ?array {
        $sql = "SELECT * FROM users WHERE email = '" . $email . "'";
        $stmt = $this->pdo->query($sql);
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row ?: null;
    }
}
