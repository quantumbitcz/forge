use formatters::format::{JsonFormatter, YamlFormatter, TomlFormatter};

#[test]
fn json_wraps_value() { assert_eq!(JsonFormatter.format("x"), "{\"v\":\"x\"}"); }
#[test]
fn yaml_wraps_value() { assert_eq!(YamlFormatter.format("x"), "v: x"); }
#[test]
fn toml_wraps_value() { assert_eq!(TomlFormatter.format("x"), "v = \"x\""); }
