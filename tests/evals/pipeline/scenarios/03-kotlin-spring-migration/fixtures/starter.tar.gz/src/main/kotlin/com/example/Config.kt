package com.example

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "feature")
class FeatureConfig {
    var enabled: Boolean = false
}
