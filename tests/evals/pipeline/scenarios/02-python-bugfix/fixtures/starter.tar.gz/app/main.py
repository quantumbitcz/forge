"""FastAPI paginated list — contains an off-by-one bug on purpose."""
from fastapi import FastAPI

app = FastAPI()
ITEMS = list(range(100))


@app.get("/items")
def items(page: int = 0, size: int = 10) -> list[int]:
    # BUG: off-by-one — returns size+1 items.
    return ITEMS[page * size : (page + 1) * size + 1]
