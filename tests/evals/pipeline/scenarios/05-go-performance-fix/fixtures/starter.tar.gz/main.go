package profiles

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type Profile struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

// BUG: N+1 — one HTTP call per user id. Refactor to batched /users?ids=...
func GetProfiles(ids []int) ([]Profile, error) {
	out := make([]Profile, 0, len(ids))
	for _, id := range ids {
		resp, err := http.Get(fmt.Sprintf("http://users.local/users/%d", id))
		if err != nil {
			return nil, err
		}
		defer resp.Body.Close()
		var p Profile
		if err := json.NewDecoder(resp.Body).Decode(&p); err != nil {
			return nil, err
		}
		out = append(out, p)
	}
	return out, nil
}
