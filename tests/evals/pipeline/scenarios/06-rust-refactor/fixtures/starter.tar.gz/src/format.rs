pub struct JsonFormatter;
pub struct YamlFormatter;
pub struct TomlFormatter;

// Three impls share the same public surface. Extract a `Formatter` trait.
impl JsonFormatter { pub fn format(&self, input: &str) -> String { format!("{{\"v\":\"{}\"}}", input) } }
impl YamlFormatter { pub fn format(&self, input: &str) -> String { format!("v: {}", input) } }
impl TomlFormatter { pub fn format(&self, input: &str) -> String { format!("v = \"{}\"", input) } }
