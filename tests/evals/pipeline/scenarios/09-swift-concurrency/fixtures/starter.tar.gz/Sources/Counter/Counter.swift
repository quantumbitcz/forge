public final class Counter {
    public var count: Int = 0   // BUG: not actor-isolated
    public init() {}
    public func increment() { count += 1 }
}
