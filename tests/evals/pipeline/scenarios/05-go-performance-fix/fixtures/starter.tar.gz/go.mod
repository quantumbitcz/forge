module example.com/profiles
go 1.22
