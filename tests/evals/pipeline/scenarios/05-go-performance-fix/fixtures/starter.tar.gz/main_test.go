package profiles

import "testing"

func BenchmarkGetProfiles(b *testing.B) {
	ids := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
	for i := 0; i < b.N; i++ {
		_, _ = GetProfiles(ids)
	}
}
