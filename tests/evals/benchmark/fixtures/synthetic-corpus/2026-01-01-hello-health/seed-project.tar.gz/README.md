synthetic seed
