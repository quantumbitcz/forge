<?php
namespace Example\Tests;

use PHPUnit\Framework\TestCase;
use Example\UserRepository;

class UserRepositoryTest extends TestCase {
    public function testFindByEmailReturnsNullWhenAbsent(): void {
        $pdo = new \PDO('sqlite::memory:');
        $pdo->exec('CREATE TABLE users (id INTEGER PRIMARY KEY, email TEXT UNIQUE)');
        $repo = new UserRepository($pdo);
        $this->assertNull($repo->findByEmail('nobody@example.com'));
    }
}
